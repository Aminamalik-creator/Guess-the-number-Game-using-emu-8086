[2:42 PM, 1/5/2026] Roma Hassan: .MODEL SMALL
.STACK 100h

.DATA
    PROMPT_MSG DB 13,10,"Guess a number between 0 and 9: $"
    TOO_HIGH_MSG DB 13,10,"Too high, try again.$"
    TOO_LOW_MSG  DB 13,10,"Too low, try again.$"
    WIN_MSG      DB 13,10,"Congratulations! You won.$"
    TRY_MSG      DB 13,10,"Attempts: $"
    AGAIN_MSG    DB 13,10,"Play again? (Y/N): $"

    SECRET_NUM DB ?      ; Random number (ASCII)
    GUESS_CHAR DB ?
    ATTEMPTS   DB 0

.CODE
MAIN PROC FAR
    MOV AX, @DATA
    MOV DS, AX

START_GAME:
    MOV ATTEMPTS, 0

    ; -------- Generate Random Number (0-9) --------
    MOV AH, 2Ch        ; Get system time
    INT 21h
    MOV AL, DL         ; DL = hundredths of seconds
    AND AL, 09h        ; Limit 0-9
    ADD AL, '0'        ; Convert to ASCII
    MOV SECRET_NUM, �
[2:42 PM, 1/5/2026] Roma Hassan: ik ye
[2:43 PM, 1/5/2026] Roma Hassan: ; ================================
; Guess the Number Game
; Assembly Language (8086)
; Emulator: EMU8086
; ================================

.model small
.stack 100h
.data

msg1 db 13,10,"Guess the Number Game (1 to 9)",13,10,"$"
msg2 db "Enter your guess: $"
msgHigh db 13,10,"Too High!",13,10,"$"
msgLow db 13,10,"Too Low!",13,10,"$"
msgCorrect db 13,10,"Correct Guess!",13,10,"$"
msgAttempts db "Number of attempts: $"

target db ?        ; Random number
attempts db 0      ; Counter

.code
main proc
    mov ax, @data
    mov ds, ax

    ; Display welcome message
    lea dx, msg1
    mov ah, 09h
    int 21h

    ; Generate random number using system time
    mov ah, 2Ch       ; Get system time
    int 21h
    mov al, dl        ; DL contains hundredths of seconds
    mov bl, 9
    div bl            ; AL / 9
    inc ah            ; remainder + 1
    mov target, ah    ; store number (1�9)

guess_loop:

    ; Ask user to enter guess
    lea dx, msg2
    mov ah, 09h
    int 21h

    ; Read character input
    mov ah, 01h
    int 21h
    sub al, '0'       ; Convert ASCII to number
    mov bl, al

    ; Increase attempts
    inc attempts

    ; Compare guess with target
    mov al, target
    cmp bl, al
    ja too_high
    jb too_low

    ; Correct guess
    lea dx, msgCorrect
    mov ah, 09h
    int 21h

    ; Display attempts
    lea dx, msgAttempts
    mov ah, 09h
    int 21h

    mov al, attempts
    add al, '0'
    mov dl, al
    mov ah, 02h
    int 21h

    jmp exit

too_high:
    lea dx, msgHigh
    mov ah, 09h
    int 21h
    jmp guess_loop

too_low:
    lea dx, msgLow
    mov ah, 09h
    int 21h
    jmp guess_loop

exit:
    mov ah, 4Ch
    int 21h

main endp
end main