.MODEL SMALL
.STACK 100h

.DATA
    PROMPT_MSG DB 13,10,"Guess a number between 0 and 9: $"
    TOO_HIGH_MSG DB 13,10,"Too high, try again.$"
    TOO_LOW_MSG  DB 13,10,"Too low, try again.$"
    WIN_MSG      DB 13,10,"Congratulations! You won.$"
    TRY_MSG      DB 13,10,"Attempts: $"
    AGAIN_MSG    DB 13,10,"Play again? (Y/N): $"

    SECRET_NUM DB ?      ; Random number (ASCII)
    GUESS_CHAR DB ?
    ATTEMPTS   DB 0

.CODE
MAIN PROC FAR
    MOV AX, @DATA
    MOV DS, AX

START_GAME:
    MOV ATTEMPTS, 0

    ; -------- Generate Random Number (0-9) --------
    MOV AH, 2Ch        ; Get system time
    INT 21h
    MOV AL, DL         ; DL = hundredths of seconds
    AND AL, 09h        ; Limit 0-9
    ADD AL, '0'        ; Convert to ASCII
    MOV SECRET_NUM, AL

    ; -------- Display Prompt --------
    MOV AH, 9
    MOV DX, OFFSET PROMPT_MSG
    INT 21h

GUESS_LOOP:
    ; -------- Read Input --------
    MOV AH, 1
    INT 21h
    MOV GUESS_CHAR, AL

    INC ATTEMPTS

    ; -------- Compare --------
    CMP AL, SECRET_NUM
    JE GUESSED_CORRECTLY
    JG TOO_HIGH
    JL TOO_LOW

TOO_HIGH:
    MOV AH, 9
    MOV DX, OFFSET TOO_HIGH_MSG
    INT 21h
    JMP GUESS_LOOP

TOO_LOW:
    MOV AH, 9
    MOV DX, OFFSET TOO_LOW_MSG
    INT 21h
    JMP GUESS_LOOP

GUESSED_CORRECTLY:
    ; -------- Win Message --------
    MOV AH, 9
    MOV DX, OFFSET WIN_MSG
    INT 21h

    ; -------- Show Attempts --------
    MOV AH, 9
    MOV DX, OFFSET TRY_MSG
    INT 21h

    MOV AL, ATTEMPTS
    ADD AL, '0'
    MOV DL, AL
    MOV AH, 2
    INT 21h

    ; -------- Play Again --------
    MOV AH, 9
    MOV DX, OFFSET AGAIN_MSG
    INT 21h

    MOV AH, 1
    INT 21h
    CMP AL, 'Y'
    JE START_GAME
    CMP AL, 'y'
    JE START_GAME

    ; -------- Exit --------
    MOV AH, 4Ch
    INT 21h

MAIN ENDP
END MAIN